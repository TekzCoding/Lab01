/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.kau.cpit252.lab01;

/**
 *
 * @author Anas Alam
 */
public abstract class Product {

    private int id;
    private double price;
    private String name;
    private int quantity;
    private Order order;
    private double weight;

    public Product(int id, double price, String name) {
        this.id = id;
        this.price = price;
        this.name = name;
        this.quantity = 0;
    }

    public void incrementQuantity() {
        this.quantity++;
    }

    public void applySaleDiscount(double percentage) {
        this.price = this.price - ((percentage / 100) * this.price);
    }

    public final void addToShoppingCart() {
        System.out.println(this.name + " has been added to the shopping cart.");
    }

    public int getTotalQuantity() {
        return this.quantity;
    }

    public void getSellableStatus() {
        System.out.println("This product is sellable");
    }

    public String toString() {
        return "Product info:\n+Id: " + this.id + "\t" + "name: " + this.name
                + "\tPrice: SR" + this.price;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public Order getOrder() {
        return order;
    }

    public double getWeight() {
        return this.weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}
