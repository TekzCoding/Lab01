/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package edu.kau.cpit252.lab01;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Anas Alam
 */
public class ProductTest {
    
    public ProductTest() {
    }

    @org.junit.jupiter.api.Test
    public void shouldCountQuantity() {
        

        Product p1 = new Product(6745, 5.50, "Penne Pasta");
        p1.incrementQuantity();
        Product p2 = new Product(8853, 6.50, "Spaghetti Pasta");
        p2.incrementQuantity();
        Product p3 = new Product(2106, 4.50, "Linguine Pasta");
        p3.incrementQuantity();
        assertEquals(p3.getTotalQuantity(), 3);
        
    }
}
   
